<?php
error_reporting (none);
//error_reporting(E_ALL & ~E_DEPRECATED);
# # # # # # # # # # # # # # # # # # # # # # # # # # # 
# www.pixel-dusche.de                               #
# bj&ouml;rn t. knetter                                  #
# start 12/2003                                     #
#                                                   #
# post@pixel-dusche.de                              #
# frankfurt am main, germany                        #
# # # # # # # # # # # # # # # # # # # # # # # # # # # 

# navigation 
echo '
<div id="leftdiv">
	<a href="logout.php" title="home" class="nobord">logout</a>
	<div class="phone">0176.668 552 08</div>
</div>
<div id="nav">


<!--	<p><a href="navigation.php" class="nav" title="Links verwalten und Content zuweisen">Start</a></p>
	<p><a href="index.php" class="nav" title="Links verwalten und Content zuweisen">&uuml;bersicht / Hilfe</a></p> -->
	<h3>Redaktion</h3>
	<p><a href="navigation.php" class="nav" title="Links verwalten und Content zuweisen"><i class="fa fa-navicon"></i> Seitenverwaltung</a></p>
	<p><a href="image.php" class="nav" title="PDF, Bilder und Fotos verwalten"><i class="fa fa-camera-retro"></i> Bildarchiv</a>
 	<p><a href="template.php" class="nav" title="Text-Vorlagen verwalten"><i class="fa fa-puzzle-piece"></i> Text Vorlagen</a></p> 
 	<p><a href="formular.php" class="nav" title="Formulare verwalten" style="color:#a2a2a2;"><i class="fa fa-tasks"></i> Formulare</a></p> 
	
	<h3>Uploads</h3>
	<p><a href="pdf_group.php" class="nav" title="PDF\'s verwalten"><i class="fa fa-th"></i> Dokumente Downloads</a></p>

  	<h3>FAQ</h3> 
	<p><a href="morp_faq.php" class="nav" title="FAQ verwalten"><i class="fa fa-question-circle"></i> FAQ verwalten</a></p> 
<!--	
	<p><a href="bild_galerie.php?ggid=1&name=life-work&db=galerie_name" class="nav" title="bildergalerie verwalten">Bilder Galerien</a></p>

<p style="height:1px;">&nbsp;</p>

	<p><a href="morp_mitarbeiter.php" class="nav" title="verwalten"><i class="fa fa-users"></i> Mitarbeiter</a></p> 
	<p><a href="morp_abteilung.php" class="nav" title="verwalten">Abteilungen / Bereiche</a></p> 
-->
 	<h3>Such-Index</h3>
	<p><a href="_keywcreate.php" class="nav" title="backup morpheus"><i class="fa fa-search"></i> Suchindex erstellen</a></p>


<p style="height:1px;">&nbsp;</p>
	
	<h3>Backup</h3>
	<p><a href="backup_morpheus.php" class="nav" title="backup morpheus"><i class="fa fa-cloud-download"></i> Backup Daten</a></p>
	

</div>
';

?>